jQuery(function($){
  $("img.lazy").lazyload({
    effect: 'fadeIn',
    effectspeed: 5000,
    threshold: 0
  });
});
